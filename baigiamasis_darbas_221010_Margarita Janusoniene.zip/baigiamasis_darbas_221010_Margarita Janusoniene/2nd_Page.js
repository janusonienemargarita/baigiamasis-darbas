// contacts & workingHours

const telNumb = document.createElement("p");
telNumb.textContent = "+370 652 30 200";
telNumb.classList.add("workingHours")

const email = document.createElement("p");
email.textContent = "info@babycity.lt";
email.classList.add("workingHours")

const workingHours = document.createElement("p");
workingHours.textContent = "I-V: 9:00-16:00 (šventinėmis dienomis nedirbame)";
workingHours.classList.add("workingHours")

document.body.append(telNumb, email, workingHours)

const wokingHoursWrapper = document.getElementById("workingHours");
wokingHoursWrapper.append(telNumb, email, workingHours)




//main block
const main = document.createElement("main");
main.classList.add("main")
document.body.append(main)

//img
const foto = document.createElement("img");
foto.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAyVBMVEX///8DY8z1Lk0AXMoAYMsAXssAU8gAWMkAWsr0DTsAVsn0ADb3+/7+6Or1J0kAXcv1JEb3YXRQiNf2T2elu+ZumdzQ3vOKq+IyddFQgtT4fYz1HEL81dm6zu0AUcjx9vz/+PnD1vDe6Pf+7/H93+P5lqL7wMf6rbb0ADGUs+T7t7+sxOr5jpv3bX/l7fn1M1H8zdP6nql6ot9ej9k7etOyyOv2S2P4eIj5nKf2PlklcND2WG0Nac6auOZmlNr4hJL0ACEASMb3ZnnZ/Q8fAAARXUlEQVR4nO1da0PiPNOm0DNY0OWkFSjoooiiAi4LIt7P/v8f9TYzSZu0pWWlLMu+uT5BD0muZDIzmaRJoSAhISEhISEhISEhISEhISEhISEhIXEcVFpTH61jF+OAmNqappnGsYtxQDQ0RTFXk2MX44DwGdqNYxfioNiYxtuxy3BYvF3+yxL6/wPTy2OXIH9cE5zRPz1D74u3zwj+eKHyxFPZ8lGm/95Mbcrf9chN67+XIxQsNzwXi0XHeqD/Zpqy5u8OLf+2++0I5coPy2Kx9nxL/1RKimI3ubtDt1gsfx6jXPlh6VhPwZ+OoSiCmA5dxx3++ULliqV1F/7Z+D6bonB3X/77dtpqpkB0JffHJgTtAXfl+k+XJ39c34a/+8CwxI2dvFMX0ULh5v45/NMAIVVX4ZWr/06e4qtrhYKoIEIx9Wq1X0cpVo5YOrUr9huF1B8fjtiVB7do3RynYHnh2rforkf/TDVkqM7Z7Xen6L4ep2R54armM2QOzVplYkpHUGfEo3ne+vJJgFBwqFPWpELqi+kHXvnuezRF66QNxgOhUCyjSWyVGEMmpg65G/bTU8Q7cHC/wx8lRLdHLryQFvYpescs4n64RQrFIvkzsEOGZp1cearBTfcuPZW/GdDPSFcj479QSH0xJSP9G3rXeT92Ob+OZ9qENTK6aKucmJq+mN5RhkXrZJ3vFyakxKzzQqooxrhQ+OHQu7SfniBoP8Ou9mHyDLWLsJP6bXzskn4V9zUG90dhbmo89MKjFdwun2qc5vGKYXFXeNs0eIwK14vwtnfsokpsQ2VHHLucX4bZ1XfD/wbZif2NqHSVHWH3s1P7K2Fmc6MMT3U+aq5mkwN0j13Sr6Kh7chQPXZJvwrma6tcWyb9Vk92xm2MHdFYzau0NU11frk2KC+j3TaBo3ayE/t94GJ2CoUedkm7Tkxfn7Zd0x8zQuimNMpM6i8FDCcwwt3TCcExvW5Q4rQSTnftQoUwpOHflaqobXZjWlUUHT0ZYjNP1hwWCuuQoT/+DecryCQbz/BUzSEaxJAhBmcISFyRY2icrmM603ZiuE5++xRA+ls2wzDIf3oYlVIY4k+foXayBr9QqPsmX5v1fYwNJcJQa5HrxO3RZscs434gvBTN8EG8G5EhXid+XfVkXRq0CiEiDAOUTnjFsMhkG0M2E3WKGOzGsJ6Wxt+NyW4Mx8cs436Y6CUOesiwy1/vdo5Zxj1Rb/HoBddH/OXR6TptEhISEhISEhInh3/d9RoppVkv+7EvoT6b5Rj273d49HedfX7r+oOgvQNK/dbFaq2sVxctPgg+szXNaG996fcw0WyTh2F35/VdxA++o9D3EtRBw7ZLmkrm3LSSoTdY5U5grjz4HmzQ30tULqpKFKpR3WGAerEvw15DF/PWdCr1OFo26Bhy2rW7+wyYY/wA9jTzxX0Z9tVSLNtqFVmVSLt2cWqjD9Mce7QibTaGgGJmR9+T4Zit2lCrpgmiCsDBf3Nt21U6/0YCsOKnYb8JTLjNsLZpNLCbNTm0H8OxTiXTnk/r9dFmbeOUMQv3DwYs5VwYqpza6o0VyCszorkXQxqXUrtTVpHNC520oxqbssmdYQFmNmPX4tiLIUql1uYFpbkmUx6xij0EQ1rB4YXKoFOvt+pjQWtzDJujzWzW6nBsO/XoHG+vPg7fnsJ6huj0TKVRZR8q9up1Sn5Cpnp8vTrxAQkM6uNotXbqaRWQwJD2TZbv+EK1DV8bmKZtzMPp94BhZ22TdaQlozRlHC51sys2xkQzjCprsQn09bhAhk+rhqGTUg8UHTWuYROMiIYy7ciLGz+3FMWYxJDMVLOvzd66JrcISLWD/S0Yw40eKOCSjRXQ0WOqikycahv6Bxfd2Nu9p02JFmAuLkDqDgqKn5sp1F6f5GZsNycJDCFszYoTdQi06oBnWLgQVrJhXULXEVRVReelEtabpE0/XapUiNbiIjK7X9AjPQgrL21dQALDBmFlo+3FxYa+U2WaVcyNNS4w1Bo+GbVkGqyhdeJ9DOAlfrsWgXMz/lnpNoZTm62hItBKFVw4Z3Mh854R45zBsDKFJmSXLuyqYbYbo9FoujIgOzpvBAyJZTFWo05/PDOQI1QmlNDklszAZwmME9BN1dUBw0JrvsISzufz9sxP+81QRB0VF5gEhsoqGF/UNxrpJJoayPVHI1CCfSo0HMNwkmVyiQryokC/OuTm6mFCKljKBjKipfmFIUO6joxr8HVQjwiwbWn+CS2mgTBR2rQt++X0gIQ+4BgaoaJGJ747YNmGxQLVEogWtnCaM80zjNrDkdhmA51VazpDEerWFyA7LBwy5HsEpgWZQ8WHzQSJBjoe6Btps09pDCu20MnhE87UFVZJDBVtvaWGJ6TGcNUdMBRXjcAcPnSwCiZDTXOHFCr8ThYZphUqjSFyCtbFQeWtYinEGHLffUDiqt3mDEyvPx6NPsbNCRoPFJELISNABXsieRPkkkki6PNukCCondSle6kMoZZZ1UKPT58zB4Lr8LOPTVvDciqsRB+rrgHDf1tXporIUBcNLZQMtAAYQKove8R4BOaeEjbThmepDKkBHHBppY4eFSWquStjBSwydsa+YnBWV4swjJghWAONpQGFiTopWkYQs9QVNekMceEKdHIwhhmrceMM/ffAKoBj2EefrGr6XiEz6xzDiIeIvgKUBnRcFYpBpJLPAkxa0El/nyFafbXCburpA48khrgohhCBVbB+L512BoNB/2MDrcsxLInvbcI2xPtmhRpDg1NduJghzVxkMOwEKa7U7HFeIsMeyIEvpi3Q+vNAzitrkWHE9ZoH/ZDqAFKMaSnaYvPkse7ODINCg6BkLTdOZsj0xCqQB4oIQ1GLQcUEj4NwzjEH0YMZ42Lw7Z5WFkP4sNHv5NMEXbAbQ1iK7XtZPS3akaOaRkge3I3AOYPupg+gLXXRR0LvL7bkZLJpt3ZiWNGwk4el+V2GdNyAQ1U+CW6hOjLkGwIHtuEiIUhkSvpm9OuKN4wi2GJX7PjG2J4lMoz6ByD5CtShkRUyS2BYmZlUFfRKEb0O5kdoQzuQ094KWyaQaWhSJTraKfAvb8IO0GvYwesxhlHrOQnWB6a6pCHDVT/EeEMDe0QPgjiFIjI1YlKq2DOsxDf0hrhG7bHBcVypVNb4tmY3IPgz6WxoADzGEL9RqUYswoYN/rMX/WMRjBBsLAuNg125BLGfSmeOReYZahjybM0Ug5Lh1BLb2CTBf5ko9J5m6Nq6pAe5gkriGdK4mL2ar9shm6a+rfKSGSYA9+PEORLF1Nrztuo7N2aEIYzxFdV3Z+lrOm8+2DrFpK7SWyd9yKejzuUZshKSMb4ZVh/9SG6HZZyRSAhFlcUtWWwaAv6q/haqnhnGaRr8mkPNEIWJtnOyg9awo1mX6LSFyPAjzIHzXjp4Nd0lBYz0SD5kossIJrp828UmUFRz3SyQ/tN9Y9yrvrkb2SxYpdrRbTxpRGaLV9Wc63wYzzSCaGTLf68UqJAZqwqNt02rrHBWSFFoRVVdXbQ6fMX0pgYJlxr6mghEU9W71Ho3ul0IBUw2OnnA7l7GB7WQ5PbRW3Oq6nTc0p1/cLnOul1u+DZe6zaZ2Lzku8BHKaXyfheDt3G9H4Rzg75QCVqsOR6PmwmeNLRh+mrZCRl71jvRkvZEaZg0O9FHmMt0XMScvvzQIhrBPtoXcJVGuzHu11eZQ90vYNy+/Oh3NuBXHu/bopnpa3bDzBpCfAX9Lkkag7P68dZSc1MB3Zw/NOQ29TE32Y8fCpeBhenm/WFFJ9jTwDymmunNbVOrVku2kr8ctQyjVK1qxg6LKQ6KwXjaaLQO0k96nVajMR2f7keoEhISEhISEv8sXl5fb7Ofygs3Z8nIJfGz4ferX+eLz9cXj7t6brnu/R/bPvk7HE4RR/mbl/luBrzXHz6VmuPUaq5lvbPdlAsvZdiYl6V/c9jNsDG3JLj7bv7703UdLj3HfaYccVdTtqXpp2u9H5LjT3cLwaKz3Cvh2+d4ypTKNdSqhc/dke3Az/fmsR3b27D2lP32dgwt1n6+jAZNWXOA4mfZl1q62/4vcvN+fyLbsbhnPY8KZ/B3H9EZ0opz/P53dfVULNMGdR/h9u1wyFI/JwzL21PKAWfXiNsfUIQh/bvXJuO3lKD1RJO5uUOhjQvGH2AY4JtTzGtL4yXIpfPMV9NPIiRWbNvrv4Dh9cPr99c7oUlvrmP2Wmhz3ALbWXriI451v4g9Thl6Hn347Dpegrw2rU9ieHtl+SbNh1VeBPk83Pv/xHfPy5YbvHljJREkqdHOd+sn94PcvXbKqIXKBEs/hcd7K+ILeEvLiif1JcQZegsr2Ou5WLN+YQE9QkDc+Zio/FqwKzk2YcpxASQn2P9aMJjF2o/C7X0x2KSf4tMNFNS+iDG8dWpFoQQu0II9rB3h4BHYtzs44wHeSjstgNBwfBt4FjFVrkcOh4rwsejDB2B4TU2aQzwvLEKZGDFPcEnwSb4U8C/SECLK7HGxCt13ytnlnoWzF2oHaUO6J77r/vp+93hOxbVMVMwj+c3vsv4JF9iBOeCUOT9ScgoYnr3TXeuXzz5IL4CjFvgTsOCClc9IJMIQj3UoP3rw7+yJqo8CPXeEP3jEFSp+Ea2A7QwLMWsB29hzBw2cRf7vBZEhHAhXtMLavMMLxKDBXvPhLew8P4V0Ug8iS2GIXTpsMzzjJKfzlESGkJNwLgVkBo0o9jssZHgg0DJDk6YzjPQ7SKy4Dy0OAkNUmOLwIiw60Ge6BDos547txxDPbXHoH6jL3A5WEBi+guQ9CA/cBdI45DOGR63QPiLDtJMCUhn+5HOGPl3Oa/goMLyqFWMODvR6bCxeeIgTyrc29kOxckSkMvS4w4e8uOndBwLD9ySH2ArMwF2oAFCQuA4LlZNqwVIZ4vtglrBTporDb0FgCKMDN/JEYC8KXi0oJBhDi3sKgxROYTvSGaKowKmX705MGewDgeG39DZEqw8Ph+WhwJNJ0mo+nSEO+8kBSmdR8dgTAsNFQj+EMUMNRxU3ZSqKYAzLgs8BfTTNSmcwBKtPOjLYp+BMt/2RoEvFccwDf21BhZOUMMLmFR3X7bomgyEYI6JrnqPisScEhug+i11AcDdAFt0htGvE5/CoRxt1Js+unvDBLIaoYG6hDOUcg+OiT4OqhteIEY8atMA5qpVISq+JFIdWrVaGTpXFsIB+DdFhTp4HCYsMH1BfhHJKHdUwch0cdRS6pEJSfsE5Kb9ZhF5SjGF07IBV5MTFYz9ExhZ4GpW1wAs3jzi24Kp0yQbocZ+DnUbmPv+89cj/lyscfsUZgvVz3j3hfS+MJudIMMqQDsBr7rfH1+/nLo4P+QM32ZFjST7HLQsIu5azXD67LBqCrcozpM1Vez9fcrGfT/p8vmd9Rcf4TAydGpuAcFzBn+YPlYtRjERAeIICQxZadZyiG3rvZyw+net5beiocY304kbiNEVxwMCChompeedBXD/or0VaFyxOAzjnMglff8Ihxl4zCzGQkG1NKO7NrzIXaytHz93CqOFWn2O45CJ1fvuzcIFfl/51i8nfTZF1Oq4NqbXKzyVFPFnlZUSpXS9qNF7qfMYN0xNzr7Zg+OTg267lvt+Fz90sLSvsvN4n5GGJEX8I4OR+RGvSxK9HYt53D0l214OmTfc5bh/uvvuvX0fUrZiTdz18GF57wgM5u6RfwyIc5uQOjLl5B0l7B7x+Wzy8DM/B88j7SOrHb5/Dl+GPzHjdQXFX9g2IhRYk7+M3P60wbcfLN+3dER5cyXt1+WAZmpjy8c5kfw0PH11kP/17WAT+WjnvyvutYlguHMyZewv6huS8DGlbTloo6/C4eXi8unp88A6R9tkdSft4EiohISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhIfFP4/8AEqhysRL/tb8AAAAASUVORK5CYII="
foto.classList.add("foto")
main.append(foto);

// h1
const slogan = document.createElement("h1")
slogan.textContent = "Viskas jūsų mažyliams!";
slogan.classList.add("h1")
main.append(slogan)

//h2
const line = document.createElement("h2")
line.textContent = "PREKĖS APRAŠYMAS";
line.classList.add("line")

main.append(line)

//add everything to header
const headerWrapper = document.getElementById("header");
headerWrapper.append(main)


const ItemId = localStorage.getItem("ItemId");

console.log(ItemId);

const getItemID = () => {
    fetch(`https://633579deea0de5318a1455eb.mockapi.io/HairSalon/${ItemId}`)
        .then((res) => {
            return res.json();
        })
        .then((product) => {
            console.log(product);
            const element = document.createElement("div");
            element.classList.add("child");
            element.innerHTML = product.title;

            const price = document.createElement("h3");
            price.innerHTML = product.price + " €";
            element.classList.add("child");

            const city = document.createElement("h5");
            city.innerHTML = product.city;
            element.classList.add("child");

            const description = document.createElement("h5");
            description.innerHTML = product.description;
            element.classList.add("child");


            const img = document.createElement("img");
            img.setAttribute("src", product.image);
            img.setAttribute("class", "img");
            element.classList.add("child");

            const button = document.createElement("button");
            button.innerHTML = "Istrinti"
            button.addEventListener('click', () => {
                deleteItem(product.id);

            });

            document.body.append(element, price, img, city, description, button);
            element.append(img, price, city, description, button);
        });
};

getItemID();

const alertMsg = () => {
    alert("Prekė ištrinta!!!");
    window.location.replace("./1st_Page.html")
   
};

const deleteItem = (id) => {

    fetch(
        `https://633579deea0de5318a1455eb.mockapi.io/HairSalon/${ItemId}`,
        {
            method: 'DELETE',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
        }
    )
        .then((res) => {

            console.log('Product was deleted successfully');
            document.body.innerHTML = "";

            const myTimeout = setTimeout(alertMsg, 2000);

        })

        .catch((err) => {
            console.log('err', err);
        });
};

